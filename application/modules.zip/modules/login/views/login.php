<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>Login - Sistem Informasi Manajemen Data dan Pelaporan</title>
    <title><?php echo isset($title) ? $title.' - '.'Sistem Informasi Manajemen Data dan Pelaporan' : 'Sistem Informasi Manajemen Data dan Pelaporan';?></title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&amp;display=swap" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/backend/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/css/plugins.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/css/styles.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/plugins/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/plugins/highlight/styles/monokai-sublime.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/plugins/animate/animate.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/plugins/sweetalerts/sweetalert2.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/plugins/sweetalerts/sweetalert.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/backend/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css" />

</head>
<body class="form">
    <div class="form-container">
        <div class="form-form">
            <div class="form-form-wrap">
                <div class="form-container">
                    <div class="form-content">

                        <h1 class="">Login <a href="index.html"><span class="brand-name">Dashboard</span></a></h1>
                        <form class="text-left" id="frmLogin">
                            <div class="form">

                                <div id="username-field" class="field-wrapper input">
                                    <i data-feather="user"></i>
                                    <input id="username" name="username" type="text" class="form-control" placeholder="Username">
                                </div>

                                <div id="password-field" class="field-wrapper input mb-2">
                                    <i data-feather="lock"></i>
                                    <input id="password" name="password" type="password" class="form-control" placeholder="Password">
                                </div>

                                    <div class="d-sm-flex justify-content-between">
                                    <div class="field-wrapper toggle-pass periode_tahun">
                                        <select class="form-control selectpicker" id="periode" name="periode">
                                            <?php foreach ($this->portal->periode_tahun() as $key => $periode):?>
                                            <option value="<?php echo $periode['PERIODE_TAHUN']; ?>"><?php echo $periode['PERIODE_TAHUN']; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="field-wrapper">
                                        <button id="submit-login" type="submit" class="btn btn-primary" value="">Masuk</button>
                                    </div>
                                    
                                </div>

                            </div>
                        </form>                        
                        <p class="terms-conditions">© 2020 All Rights Reserved. <a href="#">Aplikasi Manajemen Data dan Pelaporan</a></p>

                    </div>                    
                </div>
            </div>
        </div>
        <div class="form-image">
            <div class="l-image">
                <div class="l-login-box">
                    <img src="<?php echo base_url();?>assets/backend/img/logo.png" class="logo" style="display:none">
                    <h1>Sistem Aplikasi<br>Manajemen Data dan Pelaporan </h1>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo base_url();?>assets/backend/js/libs/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url();?>assets/backend/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/backend/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/backend/plugins/font-icons/feather/feather.min.js"></script>
    <script src="<?php echo base_url();?>assets/backend/plugins/sweetalerts/sweetalert2.min.js"></script>
    <script src="<?php echo base_url();?>assets/backend/plugins/bootstrap-select/bootstrap-select.min.js"></script>
    <!-- <script src="<?php echo base_url();?>assets/backend/plugins/sweetalerts/custom-sweetalert.js"></script> -->
    <script type="text/javascript">
        $(document).ready(function() {
            feather.replace();

            $('#submit-login').on('click',function(e){
                e.preventDefault();
                var username = $('#username').val();
                var password = $('#password').val();
                var periode = $('#periode').val();

                $.ajax({
                    type : "POST",
                    url  : "<?php echo base_url('login/sign')?>",
                    dataType : "JSON",
                    data : {username: username, password: password, periode: periode},
                    cache : false,
                    success: function(data){
                        if(data.success == true) {
                            const toast = swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 2000,
                                padding: '2em'
                            });
                            toast({
                                type: 'success',
                                title: data.message,
                                padding: '2em',
                            })

                            window.location = data.url;
                            setTimeout(function(){
                                window.location = data.url;
                            }, 3000);
                        }
                        else {
                            const toast = swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 2000,
                                padding: '2em'
                            });
                            toast({
                                type: 'error',
                                title: data.message,
                                padding: '2em',
                            })
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>