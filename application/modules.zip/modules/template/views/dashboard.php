<?php
// $this->load->view('header');
// $this->load->view('sidebar');
// $this->load->view($page);
// $this->load->view('footer');


$this->load->view('main/header');
$this->load->view('sidebar');
$this->load->view($page);
$this->load->view('main/footer');
?>
