<?php
	$this->load->view('main/header');
	$this->load->view('main/sidebar');
	$this->load->view($page);
	$this->load->view('main/footer');
?>
