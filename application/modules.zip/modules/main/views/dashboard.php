<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="row layout-spacing">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 layout-top-spacing">
        <div class="user-profile layout-spacing">
            <div class="widget-content widget-content-area">
                <div class="d-flex justify-content-between">

                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <div class="float-containers">
                        <div class="dashboard-card-container">
                          <h1 class="tile-title"><?php echo num_format($total_indikator['total']);?></h1>
                          <p class="tile-subtitle">Total Indikator</p>
                          <div class="linee"></div>
                          <div class="shard-overlay course-colour"></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="float-containers">
                        <div class="dashboard-card-container">
                          <h1 class="tile-title"><?php echo($total_urusan['total_urusan']);?></h1>
                          <p class="tile-subtitle">Urusan</p>
                          <div class="linee"></div>
                          <div class="shard-overlay course-colour"></div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="float-containers">
                        <div class="dashboard-card-container">
                          <h1 class="tile-title"><?php echo num_format($total_terisi);?> %</h1>
                          <p class="tile-subtitle">Keterisian Data</p>
                          <div class="linee"></div>
                          <div class="shard-overlay course-colour"></div>
                        </div>
                        </div>
                    </div>
                </div>
                
                
                
            </div>
        </div>
    </div>
</div>
    <script>
        $(document).ready(function() {
            feather.replace();
            $(".disabled-results").select2();
            App.init();
        });
    </script>